<?php namespace App\Models;

use Eloquent;

class Timezone extends Eloquent
{
    public $timestamps = false;
}
