<?php namespace App\Models;

use Eloquent;

class Font extends Eloquent
{
    public $timestamps = false;
}
