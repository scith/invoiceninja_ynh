<?php namespace App\Models;

use Eloquent;

class PaymentType extends Eloquent
{
    public $timestamps = false;
}
