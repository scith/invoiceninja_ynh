<?php namespace App\Models;

use Eloquent;

class DatetimeFormat extends Eloquent
{
    public $timestamps = false;
}
