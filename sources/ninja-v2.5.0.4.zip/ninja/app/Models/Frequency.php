<?php namespace App\Models;

use Eloquent;

class Frequency extends Eloquent
{
    public $timestamps = false;
}
