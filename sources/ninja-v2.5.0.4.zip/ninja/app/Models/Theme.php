<?php namespace App\Models;

use Eloquent;

class Theme extends Eloquent
{
    public $timestamps = false;
}
