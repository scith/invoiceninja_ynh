<?php namespace App\Models;

use Eloquent;

class Affiliate extends Eloquent
{
    public $timestamps = true;
    protected $softDelete = true;
}
