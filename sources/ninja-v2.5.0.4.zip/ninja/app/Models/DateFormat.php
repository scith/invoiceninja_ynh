<?php namespace App\Models;

use Eloquent;

class DateFormat extends Eloquent
{
    public $timestamps = false;
}
