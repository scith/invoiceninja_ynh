<?php namespace App\Models;

use Eloquent;

class InvoiceStatus extends Eloquent
{
    public $timestamps = false;
}
